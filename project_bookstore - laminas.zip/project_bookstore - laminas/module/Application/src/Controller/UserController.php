<?php

namespace Application\Controller;
 use Album\Controller\AlbumController;
use Laminas\Session;
use Laminas\View\Model\ViewModel;
class UserController extends AbstractController
{
    public function indexAction() {
        $userSession = new Session\Container('user');
        
        return new ViewModel([
            'user' => $userSession->details,
             'user'=> $this->redirect()->toRoute('album', ['action' => 'view'])

        ]);
    }  
//       public function rateAction()
// {
//     $id = (int) $this->params()->fromRoute('id');
//     if (!$id) {
//         return $this->redirect()->toRoute('album', ['action' => 'cart']);
//     }

//     $request = $this->getRequest();
//     if ($request->isPost()) {
//         // $del = $request->getPost('rate', 'one');

//         // if ($del == 'five') {
//         //     $id = (int) $request->getPost('id');
//         //      $this->table->getAlbum($id);
//          }
//         $rate = $request->getPost('rate');
//         if($rate == 1){
//             $rate = (int) $request->getPost('id');
//             $this->table->getAlbum($id);
//             $rating = 1;
//             return $rating;
//          }
//          $rate = $request->getPost('rate');
//          if($rate == 2){
//              $rate = (int) $request->getPost('id');
//              $this->table->getAlbum($id);
//              $rating = 1;
//              return $rating;
//           }

//     return [
//         'id'    => $id,
//         'rating'=> $rating,
//         'album' => $this->table->getAlbum($id),

//     ];
// }

}
