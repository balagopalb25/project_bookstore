<?php
namespace Application\Model;
use Application\Model\Rowset\User;

class UsersTable extends AbstractTable
{
    public function getById($id)
    {
        $id = (int) $id;
        $rowset = $this->tableGateway->select(array('id' => $id));
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception('user not found with id: '.$id);
        }
        return $row;
    }
  
    public function save(User $userModel, $extraData = [])
    {
        $data = [
            'username' => $userModel->getUsername(),
            'email' => $userModel->getEmail(),
            'password' => $userModel->getPassword(),
            'password_salt' => $userModel->getPasswordSalt(),
           // 'name' => $userModel->getName()
        ];
        
        if (!empty($extraData)) {
            $data = array_merge($data, $extraData);
	}
        return parent::saveRow($userModel, $data);
    }
   
}


