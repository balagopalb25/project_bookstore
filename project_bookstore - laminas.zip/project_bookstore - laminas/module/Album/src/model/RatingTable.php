<?php
namespace Album\Model;

use Album\Model\AlbumTable;
use Album\Form\RatingForm;
use RuntimeException;
use Laminas\Db\TableGateway\TableGatewayInterface;
use Laminas\Session;
use Laminas\Db\Sql\Join;
use Laminas\Db\sql\Select;
use Laminas\Db\sql\Insert;
use Laminas\Http\PhpEnvironment\Request;
use Album\Model\Album;
use Album\Form\AlbumForm;
use Laminas\Db\Sql\Where;


class RatingTable
{
    private $tableGateway;

    public function __construct(TableGatewayInterface $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }

    public function fetchAll()
    {
        return $this->tableGateway->select();
    }

    public function getRating($id)
    {
        $id = (int) $id;
        $rowset = $this->tableGateway->select(['id' => $id]);
           $rowset = $this->tableGateway->select(function(Select $select )use($id){
           $select->join('album','rating.user_id = album.id',[])->where(['album.id'=>$id]);});
           $row = $rowset->current();
        if (! $row) {
            throw new RuntimeException(sprintf(
                'Could not find row with identifier %d',
                $id
            ));
        }
        return $row;

    }

    public function getAll()
    {
          $userSession = new Session\Container('user');
          $userid= $userSession->details->getId();
          //$albumid = $this->getAlbum($id);
          $ratingid= $this->getRating($id);
          $rowset = $this->tableGateway->select(function(Select $select ){
          $select->join('album','rating.albumid = album.id',[]);});
          $row = $rowset->current();
        if (! $row) {
            throw new RuntimeException(sprintf(
                'Could not find row with identifier %d',
                $id
            ));
        }
    }


    public function saveRating(Rating $rating)
    {
         $userSession = new Session\Container('user');
         $data = [
            'albumid'=>$rating->albumid,
            'rating'=>$rating->rating,
            'user_id'=>$userSession->details->getId()
        ];

        $id = (int) $rating->id;

        if ($id === 0) {
            $this->tableGateway->insert($data);
            return;
        }
        try {
            $this->getRating($id);
        } catch (RuntimeException $e) {
            throw new RuntimeException(sprintf(
                'Cannot update rating with identifier %d; does not exist',
                $id
            ));
        }
        $this->tableGateway->update($data, ['id' => $id]);
    }

}
// $select->join(
//     'foo',
//     'id = bar.id', 
// );       
?>