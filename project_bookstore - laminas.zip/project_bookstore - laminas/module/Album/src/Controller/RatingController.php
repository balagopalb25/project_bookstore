<?php
namespace Album\Controller;

use Album\Model\RatingTable;
use Album\Model\AlbumTable;
use Album\Model\Album;
use Album\Form\AlbumForm;
use Album\Form\RatingForm;
use Laminas\Form\Element;
use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\Session;
use Laminas\View\Model\ViewModel;
use Album\Model\Rating;

class RatingController extends AbstractActionController
{
    private $table;

    public function __construct(RatingTable $table)
    {
        $this->table = $table;
    }

    // public function indexAction()
    // {
    //     return new ViewModel([
    //         'rating' => $this->table->fetchAll(),
    //         $this->redirect()->toRoute('album',['action'=>'view']),
    //     ]);
    // }

    public function rateAction()
    {
        $form = new RatingForm();
        $form->get('submit')->setValue('Add');
        $request = $this->getRequest();
        $rating = new Rating();
        //$form->setInputFilter($rating->getInputFilter());
        $form->setData($request->getPost());
        if (! $form->isValid()) {
            return ['form' => $form];
        }
        $rating->exchangeArray($form->getData());
        $this->table->saveRating($rating);
        // $getrate = $this->table->getRating($rating);
        return[
        //    'rate'=> $getrate,
            $this->redirect()->toRoute('album',['action'=>'view']),
        ];
    } 

    // public function rateviewAction(){
   
    // }
    

    }




