<?php 
namespace Album\Form;
use Album\Model;
use Laminas\Form\Element;
use Laminas\Filter\StringTrim;
use Laminas\Filter\StripTags;
use Laminas\Form\Element\Text;
use Laminas\Validator\StringLength;
use Laminas\InputFilter\InputFilterProviderInterface;
use Laminas\Form\Form;

class AlbumForm extends Form
{
    
    public function __construct($name = null)
    {
        // We will ignore the name provided to the constructor
        parent::__construct('album');

        $this->add([
            'name' => 'id',
            'type' => 'hidden',
        ]);
        $this->add([
            'name' => 'title',
            'type' => 'text',
            'options' => [
                'label' => 'Title',
            ],
        ]);
        $this->add([
            'name' => 'artist',
            'type' => 'text',
            'options' => [
                'label' => 'Artist',
            ],
        ]);

        $this->add([
            'name' => 'price',
            'type' => 'text',
            'options' => [
                'label' => 'Price',
            ],
        ]);
        // 
        $file = new Element\File('file');
        // $file->setLabel('Upload file');
        // $file->setAttribute('id', 'Upload file');

        $this->add($file);
        $this->add([
            'type'  => 'file',
            'name' => 'file',
            'attributes' => [                
                'id' => 'file'
            ],
            'options' => [
                'label' => 'Upload image',
            ],
        
        ]);
     
        $this->add([
            'name' => 'submit',
            'type' => 'submit',
            'attributes' => [
                'value' => 'Go',
                'id'    => 'submitbutton',
            ],
        ]);
        
    }



 // file upload
    // public function init(): void
    // {
    //     // Add form elements
    //     $this->add([
    //         'name'    => 'title',
    //         'type'    => Text::class,
    //         'options' => [
    //             'label' => 'Title',
    //         ],
    //     ]);

    
// }
// public function getInputFilterSpecification(): array
// {
//     return [
//         // Add inputs
//         [
//             'name'    => 'title',
//             'filters' => [
//                 ['name' => StripTags::class],
//                 ['name' => StringTrim::class],
//             ],
//             'validators' => [
//                 [
//                     'name'    => StringLength::class,
//                     'options' => [
//                         'min' => 1,
//                         'max' => 100,
//                     ],
//                 ],
//             ],
//         ],
//         // …
//     ];
// }
}
?>