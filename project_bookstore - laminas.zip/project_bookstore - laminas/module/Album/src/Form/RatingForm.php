<?php 
namespace Album\Form;
use Album\Model;
use Laminas\Form\Element;
use Laminas\Form\Form;

class RatingForm extends Form
{
    
    public function __construct($name = null)
    {
        // We will ignore the name provided to the constructor
        parent::__construct('rating');

        $this->add([
            'name' => 'id',
            'type' => 'hidden',
        ]);
        $this->add([
            'name' => 'albumid',
            'type' => 'hidden',
        ]);
        $this->add([
            'name' => 'rating',
            'type' => 'text',
            'options' => [
                'label' => 'rating',
            ],
        ]);
        $this->add([
            'name' => 'submit',
            'type' => 'submit',
            'attributes' => [
                'value' => 'Go',
                'id'    => 'submitbutton',
            ],
        ]);
    }
}
?>