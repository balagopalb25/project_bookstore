<?php

namespace Utils\Security;

class Adapter extends \Laminas\Authentication\Adapter\DbTable\CredentialTreatmentAdapter {
    
}
