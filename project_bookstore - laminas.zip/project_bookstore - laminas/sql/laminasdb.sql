-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 31, 2024 at 05:03 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laminasdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `album`
--

CREATE TABLE `album` (
  `id` int(11) NOT NULL,
  `artist` varchar(250) NOT NULL,
  `title` varchar(250) NOT NULL,
  `price` varchar(100) NOT NULL,
  `file` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `album`
--

INSERT INTO `album` (`id`, `artist`, `title`, `price`, `file`) VALUES
(5, 'author 1', 'Book 1', '500', ''),
(6, 'author 2', 'Book 2', '300', ''),
(7, 'author 3', 'Book 3', '200', ''),
(8, 'author 4', 'Book 4', '250', ''),
(9, 'author 5', 'Book 5', '300', ''),
(10, 'author 6', 'Book 6', '350', ''),
(11, 'author 7', 'Book 7', '400', ''),
(12, 'author 8', 'Book 8', '500', '');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(40) CHARACTER SET utf8 NOT NULL,
  `url` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `parent_id` int(11) NOT NULL DEFAULT 0,
  `required` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `page_contents`
--

CREATE TABLE `page_contents` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `page_lang_contents`
--

CREATE TABLE `page_lang_contents` (
  `id` int(10) UNSIGNED NOT NULL,
  `lang` varchar(2) CHARACTER SET utf32 NOT NULL,
  `content` text CHARACTER SET utf8 NOT NULL,
  `page_content_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `page_metadata`
--

CREATE TABLE `page_metadata` (
  `id` int(10) UNSIGNED NOT NULL,
  `lang` varchar(3) CHARACTER SET latin1 NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `keywords` varchar(150) NOT NULL,
  `page_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `page_to_contents`
--

CREATE TABLE `page_to_contents` (
  `id` int(10) UNSIGNED NOT NULL,
  `page_id` int(11) NOT NULL,
  `content_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE `rating` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `albumid` int(11) NOT NULL,
  `rating` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rating`
--

INSERT INTO `rating` (`id`, `user_id`, `albumid`, `rating`) VALUES
(1, 9, 5, 4),
(2, 9, 6, 5),
(3, 9, 7, 2),
(4, 9, 5, 1),
(5, 9, 6, 4),
(7, 10, 6, 4),
(8, 10, 7, 5),
(10, 9, 5, 2),
(19, 9, 9, 2),
(20, 9, 13, 3),
(21, 9, 14, 3),
(23, 9, 6, 4),
(30, 9, 5, 2),
(31, 9, 5, 2),
(32, 9, 5, 4),
(33, 9, 5, 4),
(34, 9, 5, 3),
(35, 9, 5, 5),
(36, 9, 5, 4);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(55) NOT NULL,
  `email` varchar(25) NOT NULL,
  `password` varchar(300) NOT NULL,
  `password_salt` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_salt`) VALUES
(7, 'admin', 'admin@gmail.com', '7fc2eec212931938713b77ecf4ec588747b64daddd6b9fbd696a394ef94d953de24b776640147f285f362b330e51ada578f904520bc5f6a2615d6beaeee2306d', 'xJMq3'),
(8, 'newuser', 'newuser@gmail.com', 'd86767990549d7c9f86d9bb1e9b5ccf87e75b2f9345dbb6cda4e8363749f6151f1af8f31c903f44fa79aa70f73e36a36999d662b0e66669f04c377b838b1da12', 'mYpNEH'),
(9, 'testnew', 'testnew@gmail.com', '11b881b4eba64eefd54386c2fe870d5e3ad29b4f762800f35c64f8305eeefc1533c12b246c35145e2698050b2da02c010cdec2f42ee7c54166d0ed11467e9bb6', 'zFdtsEH'),
(10, 'nrestedf', 'nrestedf@gmail.com', 'd205de72c6cf23657b0f1781bbccb10e9554db1e748290d1d633f614d606ef4f5c45b8d442522a810b6e37cb32c14ad98da9984cb6b13963133d1936f200444b', 'efmFwcn');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `album`
--
ALTER TABLE `album`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parent_id` (`parent_id`);

--
-- Indexes for table `page_contents`
--
ALTER TABLE `page_contents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `page_lang_contents`
--
ALTER TABLE `page_lang_contents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lang` (`lang`);

--
-- Indexes for table `page_metadata`
--
ALTER TABLE `page_metadata`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `page_to_contents`
--
ALTER TABLE `page_to_contents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `page_id` (`page_id`,`content_id`);

--
-- Indexes for table `rating`
--
ALTER TABLE `rating`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `album`
--
ALTER TABLE `album`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `page_contents`
--
ALTER TABLE `page_contents`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `page_lang_contents`
--
ALTER TABLE `page_lang_contents`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `page_metadata`
--
ALTER TABLE `page_metadata`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `page_to_contents`
--
ALTER TABLE `page_to_contents`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rating`
--
ALTER TABLE `rating`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
